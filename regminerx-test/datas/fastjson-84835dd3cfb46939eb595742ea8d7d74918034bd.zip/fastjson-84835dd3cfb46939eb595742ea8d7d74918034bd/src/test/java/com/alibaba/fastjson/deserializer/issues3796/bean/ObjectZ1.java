package com.alibaba.fastjson.deserializer.issues3796.bean;



import java.util.List;


public class ObjectZ1 {
    private int a;


    private int b;


    private int c;


    private int d;


    private int e;


    private List<Integer> f;


    private List<Integer> g;


    private List<Integer> h;


    private List<ObjectZ1_A> i;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        this.d = d;
    }

    public int getE() {
        return e;
    }

    public void setE(int e) {
        this.e = e;
    }

    public List<Integer> getF() {
        return f;
    }

    public void setF(List<Integer> f) {
        this.f = f;
    }

    public List<Integer> getG() {
        return g;
    }

    public void setG(List<Integer> g) {
        this.g = g;
    }

    public List<Integer> getH() {
        return h;
    }

    public void setH(List<Integer> h) {
        this.h = h;
    }

    public List<ObjectZ1_A> getI() {
        return i;
    }

    public void setI(List<ObjectZ1_A> i) {
        this.i = i;
    }
}
