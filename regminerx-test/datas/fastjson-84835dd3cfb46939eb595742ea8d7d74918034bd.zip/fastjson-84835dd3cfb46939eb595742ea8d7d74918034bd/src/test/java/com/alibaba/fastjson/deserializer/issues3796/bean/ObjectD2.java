package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;


public class ObjectD2 {
	
	private int a;
	
	private int b;
	
	private int c;
	
	private List<Integer> d;
	private List<Integer> e;
	private List<Integer> f;
	private List<Integer> g;
	private List<Integer> h;
	
	private List<CommonObject> i;
	
	private int j;
	
	private int k;
	
	private int l;
	private boolean m;
	private boolean n;
	
	private int o;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public List<Integer> getD() {
		return d;
	}

	public void setD(List<Integer> d) {
		this.d = d;
	}

	public List<Integer> getE() {
		return e;
	}

	public void setE(List<Integer> e) {
		this.e = e;
	}

	public List<Integer> getF() {
		return f;
	}

	public void setF(List<Integer> f) {
		this.f = f;
	}

	public List<Integer> getG() {
		return g;
	}

	public void setG(List<Integer> g) {
		this.g = g;
	}

	public List<Integer> getH() {
		return h;
	}

	public void setH(List<Integer> h) {
		this.h = h;
	}

	public List<CommonObject> getI() {
		return i;
	}

	public void setI(List<CommonObject> i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public boolean isM() {
		return m;
	}

	public void setM(boolean m) {
		this.m = m;
	}

	public boolean isN() {
		return n;
	}

	public void setN(boolean n) {
		this.n = n;
	}

	public int getO() {
		return o;
	}

	public void setO(int o) {
		this.o = o;
	}
}
