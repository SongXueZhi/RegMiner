package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;

public class ObjectD {
	
	private int a;

	
	private int b;

	
	private int c;

	
	private int d;

	
	private boolean e;

	
	private List<ObjectD_A> f;

	
	private int g;

	
	private int h;

	
	private long i;

	
	private long j;

	
	private int k;

	
	private int l;

	
	private ObjectD_B m;
	
	private long n;
	
	private long o;
	
	private long dieFans;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public boolean isE() {
		return e;
	}

	public void setE(boolean e) {
		this.e = e;
	}

	public List<ObjectD_A> getF() {
		return f;
	}

	public void setF(List<ObjectD_A> f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public long getI() {
		return i;
	}

	public void setI(long i) {
		this.i = i;
	}

	public long getJ() {
		return j;
	}

	public void setJ(long j) {
		this.j = j;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public ObjectD_B getM() {
		return m;
	}

	public void setM(ObjectD_B m) {
		this.m = m;
	}

	public long getN() {
		return n;
	}

	public void setN(long n) {
		this.n = n;
	}

	public long getO() {
		return o;
	}

	public void setO(long o) {
		this.o = o;
	}

	public long getDieFans() {
		return dieFans;
	}

	public void setDieFans(long dieFans) {
		this.dieFans = dieFans;
	}
}
