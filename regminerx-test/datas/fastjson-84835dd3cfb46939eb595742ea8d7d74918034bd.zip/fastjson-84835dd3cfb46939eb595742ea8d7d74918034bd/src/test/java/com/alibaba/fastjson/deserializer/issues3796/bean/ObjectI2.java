package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;


public class ObjectI2 {
    private int a;

    
    private List<Integer> b;

    
    private boolean c;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public List<Integer> getB() {
        return b;
    }

    public void setB(List<Integer> b) {
        this.b = b;
    }

    public boolean isC() {
        return c;
    }

    public void setC(boolean c) {
        this.c = c;
    }
}
