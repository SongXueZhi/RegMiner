package com.alibaba.fastjson.deserializer.issues3796.bean;






public class ObjectG1 {
	private int a;
	private int b;
	private int c;
}
