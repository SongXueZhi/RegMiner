package com.alibaba.fastjson.deserializer.issues3796.bean;






public class ObjectY_A {

	
	private int a = 0;

	
	private int b;

	
	private int c;

	
	private int d;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}
}
