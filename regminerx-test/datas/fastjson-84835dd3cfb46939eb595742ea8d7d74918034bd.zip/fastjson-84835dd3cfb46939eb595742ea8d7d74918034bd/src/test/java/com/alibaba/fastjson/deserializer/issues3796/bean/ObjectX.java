package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectX {

	
	private long a = 0;
	
	private int b;

	
	private List<Integer> c;

	
	private int d = 0;

	
	private int e;

	
	private List<Integer> f;

	
	private List<String> g;
	
	private List<Integer> h;

	public long getA() {
		return a;
	}

	public void setA(long a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public List<Integer> getC() {
		return c;
	}

	public void setC(List<Integer> c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public List<Integer> getF() {
		return f;
	}

	public void setF(List<Integer> f) {
		this.f = f;
	}

	public List<String> getG() {
		return g;
	}

	public void setG(List<String> g) {
		this.g = g;
	}

	public List<Integer> getH() {
		return h;
	}

	public void setH(List<Integer> h) {
		this.h = h;
	}
}
