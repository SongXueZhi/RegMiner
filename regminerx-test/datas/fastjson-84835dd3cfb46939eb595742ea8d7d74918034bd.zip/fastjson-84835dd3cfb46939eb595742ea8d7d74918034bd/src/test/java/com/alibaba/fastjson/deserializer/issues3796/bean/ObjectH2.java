package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;


public class ObjectH2 {

    
    private boolean a;


    
    private int b;

    
    private int c;

    
    private boolean d;

    
    private List<CommonObject> e;

    public boolean isA() {
        return a;
    }

    public void setA(boolean a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public boolean isD() {
        return d;
    }

    public void setD(boolean d) {
        this.d = d;
    }

    public List<CommonObject> getE() {
        return e;
    }

    public void setE(List<CommonObject> e) {
        this.e = e;
    }
}
