package com.alibaba.fastjson.deserializer.issues3796.bean;



import java.util.List;


public class ObjectU1_B {
	
	private int a;
	
	private long b;
	
	private List<ObjectU1_C> c;
	
	private boolean d;
	
	private boolean e;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public long getB() {
		return b;
	}

	public void setB(long b) {
		this.b = b;
	}

	public List<ObjectU1_C> getC() {
		return c;
	}

	public void setC(List<ObjectU1_C> c) {
		this.c = c;
	}

	public boolean isD() {
		return d;
	}

	public void setD(boolean d) {
		this.d = d;
	}

	public boolean isE() {
		return e;
	}

	public void setE(boolean e) {
		this.e = e;
	}
}
