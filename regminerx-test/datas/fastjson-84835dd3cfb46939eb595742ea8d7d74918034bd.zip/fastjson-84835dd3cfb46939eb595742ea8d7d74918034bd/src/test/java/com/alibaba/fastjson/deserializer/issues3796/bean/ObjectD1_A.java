package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;

public class ObjectD1_A {
	
	private int a;
	
	private List<Integer> b;
	
	private int c;

	
	private CommonObject d;

	
	private int e;

	
	private int f;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public List<Integer> getB() {
		return b;
	}

	public void setB(List<Integer> b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public CommonObject getD() {
		return d;
	}

	public void setD(CommonObject d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}
}
