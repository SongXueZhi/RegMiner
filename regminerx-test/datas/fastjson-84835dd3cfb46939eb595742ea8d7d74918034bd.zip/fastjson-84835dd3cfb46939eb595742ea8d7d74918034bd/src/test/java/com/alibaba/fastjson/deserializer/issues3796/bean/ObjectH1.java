package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectH1 {

	
	private List<Integer> a;

	
	private List<Integer> b;
	
	private List<Integer> c;
	
	private List<Integer> d;
	
	private int e;

	
	private int f;
	
	private int g;
	
	private int h;
	
	private int i;
	
	private int j;
	
	private int k;
	
	private int l;
	
	private List<Integer> m;
	
	private List<Integer> n;
	
	private List<Integer> o;

	public List<Integer> getA() {
		return a;
	}

	public void setA(List<Integer> a) {
		this.a = a;
	}

	public List<Integer> getB() {
		return b;
	}

	public void setB(List<Integer> b) {
		this.b = b;
	}

	public List<Integer> getC() {
		return c;
	}

	public void setC(List<Integer> c) {
		this.c = c;
	}

	public List<Integer> getD() {
		return d;
	}

	public void setD(List<Integer> d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public List<Integer> getM() {
		return m;
	}

	public void setM(List<Integer> m) {
		this.m = m;
	}

	public List<Integer> getN() {
		return n;
	}

	public void setN(List<Integer> n) {
		this.n = n;
	}

	public List<Integer> getO() {
		return o;
	}

	public void setO(List<Integer> o) {
		this.o = o;
	}
}
