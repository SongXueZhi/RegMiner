package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectM2 {

    
    private long a;

    
    private int b;

    
    private boolean c;

    
    private int d;

    
    private List<ObjectM2_A> e;

    public long getA() {
        return a;
    }

    public void setA(long a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public boolean isC() {
        return c;
    }

    public void setC(boolean c) {
        this.c = c;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        this.d = d;
    }

    public List<ObjectM2_A> getE() {
        return e;
    }

    public void setE(List<ObjectM2_A> e) {
        this.e = e;
    }
}
