package com.alibaba.fastjson.deserializer.javabean;

/**
 * @author ylyue
 * @since 2021/3/24
 */

public enum ConvertEnum {

    A_A, BB_B;

}
