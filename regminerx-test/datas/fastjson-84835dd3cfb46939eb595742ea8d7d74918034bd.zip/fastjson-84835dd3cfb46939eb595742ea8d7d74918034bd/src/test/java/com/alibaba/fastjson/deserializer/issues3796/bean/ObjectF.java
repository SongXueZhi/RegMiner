package com.alibaba.fastjson.deserializer.issues3796.bean;

import java.util.List;


public class ObjectF {
	
	protected long a;

	
	protected int b;

	
	protected  int c;

	
	protected long d;

	
	protected long e;

	
	protected String f = "";

	
	protected long g;
	
	protected String h = "";
	
	protected String i = "";
	
	protected int j;
	
	protected long k;

	
	protected int l;

	
	private int m;
	
	protected List<Integer> n;

	
	protected List<String> o;

	
	protected List<CommonObject> p;

	public long getA() {
		return a;
	}

	public void setA(long a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public long getD() {
		return d;
	}

	public void setD(long d) {
		this.d = d;
	}

	public long getE() {
		return e;
	}

	public void setE(long e) {
		this.e = e;
	}

	public String getF() {
		return f;
	}

	public void setF(String f) {
		this.f = f;
	}

	public long getG() {
		return g;
	}

	public void setG(long g) {
		this.g = g;
	}

	public String getH() {
		return h;
	}

	public void setH(String h) {
		this.h = h;
	}

	public String getI() {
		return i;
	}

	public void setI(String i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public long getK() {
		return k;
	}

	public void setK(long k) {
		this.k = k;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public List<Integer> getN() {
		return n;
	}

	public void setN(List<Integer> n) {
		this.n = n;
	}

	public List<String> getO() {
		return o;
	}

	public void setO(List<String> o) {
		this.o = o;
	}

	public List<CommonObject> getP() {
		return p;
	}

	public void setP(List<CommonObject> p) {
		this.p = p;
	}
}
