package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectM1_C {
    
    private int a;

    
    private int b;

    
    private int c;


    
    private int d;

    
    private int e;

    
    private int f;

    
    private int g;

    
    private List<Integer> h;

    
    private List<Integer> i;

    
    private int j;

    
    private int k;

    
    private int l;

    
    private int m;

    
    private int n;

    
    private int o;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        this.d = d;
    }

    public int getE() {
        return e;
    }

    public void setE(int e) {
        this.e = e;
    }

    public int getF() {
        return f;
    }

    public void setF(int f) {
        this.f = f;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public List<Integer> getH() {
        return h;
    }

    public void setH(List<Integer> h) {
        this.h = h;
    }

    public List<Integer> getI() {
        return i;
    }

    public void setI(List<Integer> i) {
        this.i = i;
    }

    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public int getL() {
        return l;
    }

    public void setL(int l) {
        this.l = l;
    }

    public int getM() {
        return m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getO() {
        return o;
    }

    public void setO(int o) {
        this.o = o;
    }
}